import React, { useState } from "react";
import { v4 } from "uuid";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";

const Home = () => {
    console.log("REACT_APP_BACKEND_URL", process.env.REACT_APP_BACKEND_URL);

    const navigate = useNavigate();
    const [roomID, setroomID] = useState("");
    const [username, setusername] = useState("");

    const createRoom= (e) => {
        e.preventDefault();
        const id = v4();
        console.log(id);
        setroomID(id);
        toast.success("Created a new Session",{
            style:{
                border: '2px solid #EF00DE',
                padding: '16px',
                color: 'white',
                background: '#282a36'
            },
            iconTheme: {
                primary: 'green',
                secondary: 'white',
            },
        })
    }
    const joinRoom = () =>{
        if(!roomID || !username){
            toast.error("Session ID and Username is required",{
                style:{
                    border: '2px solid #EF00DE',
                    padding: '16px',
                    color: 'white',
                    background: '#282a36'
                },
                iconTheme: {
                    primary: 'red',
                    secondary: 'white',
                },
            })
            return;
        }
        navigate(`editor/${roomID}`,{
            state: {
                username
            }
        })

    }
    const enterpressed = (e) => {
        if(e.code == "Enter"){
            joinRoom();
        }
    }
    return (
        <div className="homepagewrapper">
            <div className="formwrapper">
                <h4 className="heading">Enter the Session ID to start collaborating</h4>
                <div className="inputwrapper">
                    <input 
                    type="text" className="inputbox" 
                    value={roomID} placeholder="Session ID" 
                    onChange={(e) => setroomID(e.target.value)}
                    onKeyDown={enterpressed}
                    />
                    <input 
                    type="text" className="inputbox" placeholder="Username"
                    value={username}
                    onChange={(e) => setusername(e.target.value)}
                    onKeyDown={enterpressed}
                    />
                    <button className="btn joinBtn" onClick={joinRoom}>Join Now</button>

                    <span className="newSession">Don't have a Session ID? &nbsp; 
                        <a href="" onClick= {createRoom} className="createnewBtn">
                            create new room
                        </a>
                    </span>
                    
                </div>
            </div>
        </div>
    );
}

export default Home;