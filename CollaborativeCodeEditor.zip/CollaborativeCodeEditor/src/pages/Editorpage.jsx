import React, { useEffect, useRef, useState } from "react";
import Client from "../components/Client";
import CodeEditor from "./CodeEditor";
import { initSocket } from "../../socket";
import { ACTIONS } from "../Actions";
import { Navigate, useLocation, useNavigate, useParams } from "react-router-dom";
import toast from "react-hot-toast";
import { Box } from "@chakra-ui/react";

const Editorpage = () => {
  const [clients, setClients] = useState([])

  const socketRef = useRef(null);
  const codeRef = useRef(null);
  const location = useLocation();
  const { roomId } = useParams();
  const reactNavigator = useNavigate();
  useEffect(() => {
    const init = async () => {
      socketRef.current = await initSocket();
      socketRef.current.on("connect_error", (err) => handleErrors(err));
      socketRef.current.on("connect_failed", (err) => handleErrors(err));

      function handleErrors(err) {
        console.log("socket error", err);
        toast.error("Socket connection failed, try again later");
        reactNavigator('/');
      }


      socketRef.current.emit(ACTIONS.JOIN, {
        roomId,
        username: location.state?.username
      })

      // listening for joined event
      socketRef.current.on(ACTIONS.JOINED,
        ({ clients, username, socketId }) => {
          if (username !== location.state?.username) {
            toast.success(`${username} joined the Session`, {
              style: {
                border: '2px solid #EF00DE',
                padding: '16px',
                color: 'white',
                background: '#282a36'
              },
              iconTheme: {
                primary: 'green',
                secondary: 'white',
              },
            });
            console.log(`${username} joined`);
          }
          setClients(clients);
          socketRef.current.emit(ACTIONS.SYNC_CODE, {
            code: codeRef.current,
            socketId

          });
        });

      //listening for disconnected
      socketRef.current.on(
        ACTIONS.DISCONNECTED,
        ({ socketId, username }) => {
          toast.success(`${username} left the Session`, {
            style: {
              border: '2px solid #EF00DE',
              padding: '16px',
              color: 'white',
              background: '#282a36'
            },
            iconTheme: {
              primary: 'green',
              secondary: 'white',
            },
          });
          setClients((prev) => {
            return prev.filter((client) => client.socketId != socketId);
          })
        }
      )
    };
    init();
    return () => {
      socketRef.current.disconnect();
      socketRef.current.off(ACTIONS.JOINED);
      socketRef.current.off(ACTIONS.DISCONNECTED);
    }
  }, []);

  async function copyRoomId() {
    try {
      await navigator.clipboard.writeText(roomId);
      toast.success("Session ID copied to your clipboard", {
        style: {
          border: '2px solid #EF00DE',
          padding: '16px',
          color: 'white',
          background: '#282a36'
        },
        iconTheme: {
          primary: 'green',
          secondary: 'white',
        },
      })
    } catch (err) {
      toast.error("Could not copy the Session ID", {
        style: {
          border: '2px solid #EF00DE',
          padding: '16px',
          color: 'white',
          background: '#282a36'
        },
        iconTheme: {
          primary: 'red',
          secondary: 'white',
        },
      })
      console.log(err);
    }
  }

  function leaveRoom() {
    reactNavigator('/');
  }

  if (!location.state) {
    return <Navigate to="/" />;
  }

  return (
    <div className="mainwrapper">
      <div className="sidepanel">
        <div className="sidepanel-inner">
          <div className="logo2">
          </div>
          <h3>Availabe Users</h3>
          <div className="clientList">
            {clients.map((client) => (
              <Client
                key={client.socketId}
                username={client.username}>
              </Client>
            ))}
          </div>
        </div>
        <button className="btn copyBtn" onClick={copyRoomId}>Copy Session ID</button>
        <button className="btn leaveBtn" onClick={leaveRoom}>Leave Session</button>
      </div>
      <div className="editorwrapper">
        <Box minH="100vh" bg="#0f0a19" color="gray.500" px={6} py={8}>
          <CodeEditor
          socketRef={socketRef}
          roomId={roomId}
          onCodeChange={(code) => { codeRef.current = code }}>
          </CodeEditor>
        </Box>
      </div>
    </div>
  );
}

export default Editorpage;